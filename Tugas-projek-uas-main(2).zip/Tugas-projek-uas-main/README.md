# pegawai

<img src="https://img.shields.io/github/license/ipang-dwi/xdesktop.svg" /> <img src="https://img.shields.io/badge/lab-firstplato.com-red.svg" />

Contoh crud sederhana dengan PHP.

Dengan native PHP

Cara memakai :
- copy semua file ke web folder kamu
- buat database baru dan lakukan import pegawai.sql ke database yang sudah dibuat
- edit file koneksi.php sesuaikan dengan setting database yang dipakai
- coba di browser


